#include "gtest/gtest.h"
#include <vector>
#include <stdexcept>
#include <pch.cpp>
#include <pch.h>

// the global test environment setup and tear down
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        srand(time(nullptr)); // initialize random seed
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
class CollectionTest : public ::testing::Test
{
protected:
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    {
        collection->clear();
        collection.reset(nullptr);
    }

    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    // if empty, the size must be 0

    add_entries(1);

    // is the collection still empty?
    // if not empty, what must the size be?
    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeGreaterThanOrEqualToSize)
{
    add_entries(5);
    ASSERT_GE(collection->max_size(), collection->size());
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityGreaterThanOrEqualToSize)
{
    add_entries(5);
    ASSERT_GE(collection->capacity(), collection->size());
}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesTheCollection)
{
    size_t initial_size = collection->size();
    collection->resize(initial_size + 5);
    ASSERT_GT(collection->size(), initial_size);
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesTheCollection)
{
    add_entries(10);
    size_t initial_size = collection->size();
    collection->resize(initial_size - 5);
    ASSERT_LT(collection->size(), initial_size);
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeDecreasesToZero)
{
    add_entries(10);
    collection->resize(0);
    ASSERT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesTheCollection)
{
    add_entries(5);
    collection->clear();
    ASSERT_TRUE(collection->empty());
}

// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseRangeErasesTheCollection)
{
    add_entries(5);
    collection->erase(collection->begin(), collection->end());
    ASSERT_TRUE(collection->empty());
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityButNotSize)
{
    size_t initial_capacity = collection->capacity();
    size_t initial_size = collection->size();
    collection->reserve(20);
    ASSERT_GT(collection->capacity(), initial_capacity);
    ASSERT_EQ(collection->size(), initial_size);
}

// TODO: Create the std::out_of_range exception test for out-of-bounds access
// Negative test: Expect std::out_of_range when accessing an invalid index
TEST_F(CollectionTest, OutOfRangeExceptionWhenAccessingInvalidIndex)
{
    add_entries(5);
    ASSERT_THROW(collection->at(10), std::out_of_range);
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
// Positive test: Ensure that adding a positive number works as expected
TEST_F(CollectionTest, EnsureNumberIsPositive)
{
    add_entries(1);
    ASSERT_GT(collection->back(), 0);
}

// Negative test: Try accessing an index that's out of range
TEST_F(CollectionTest, EnsureNegativeTestForAccessOutOfBounds)
{
    ASSERT_THROW(collection->at(100), std::out_of_range);
}
