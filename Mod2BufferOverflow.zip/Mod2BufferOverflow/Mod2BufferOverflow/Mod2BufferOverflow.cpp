#include <iomanip>
#include <iostream>
#include <cstring>

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    const std::string account_number = "CharlieBrown42";
    char user_input[20];

    std::cout << "Enter a value: ";
    std::cin.getline(user_input, sizeof(user_input)); // Use getline to prevent overflow

    // Check if the user entered more than 19 characters (leaving space for the null terminator)
    if (std::cin.fail()) {
        std::cout << "You entered too much data. Only the first 19 characters will be stored." << std::endl;
        std::cin.clear(); // Clear the error flag
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Ignore excess input
    }

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;
}
