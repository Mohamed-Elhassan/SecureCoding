#include <iostream>
#include <stdexcept>

// Custom exception class
class CustomException : public std::exception {
public:
    const char* what() const noexcept override {
        return "Custom exception occurred!";
    }
};

bool do_even_more_custom_application_logic()
{
    // Throwing a standard exception
    throw std::runtime_error("Standard exception in do_even_more_custom_application_logic!");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic()
{
    // Wrap the call to do_even_more_custom_application_logic()
    // with an exception handler that catches std::exception, displays
    // a message and the exception.what(), then continues processing
    try {
        std::cout << "Running Custom Application Logic." << std::endl;

        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        std::cout << "Caught exception in do_custom_application_logic: " << e.what() << std::endl;
    }

    // Throwing a custom exception derived from std::exception
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // Throw an exception to deal with divide by zero errors using
    // a standard C++ defined exception
    if (den == 0) {
        throw std::invalid_argument("Cannot divide by zero!");
    }
    return (num / den);
}

void do_division() noexcept
{
    // Create an exception handler to capture ONLY the exception thrown
    // by divide.
    try {
        float numerator = 10.0f;
        float denominator = 0;

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e) {
        std::cout << "Caught divide exception: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try {
        // Catch the custom exception
        try {
            do_division();
            do_custom_application_logic();
        }
        catch (const CustomException& e) {
            std::cout << "Caught custom exception in main: " << e.what() << std::endl;
        }

        // Catch std::exception
        catch (const std::exception& e) {
            std::cout << "Caught std::exception in main: " << e.what() << std::endl;
        }

        // Catch any uncaught exceptions
    }
    catch (...) {
        std::cout << "Caught an uncaught exception in main!" << std::endl;
    }
}
